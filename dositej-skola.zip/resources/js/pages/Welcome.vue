<script setup lang="ts">
import MyLayout from "@/layouts/myLayout.vue";
</script>

<template>
    <my-layout>
        Ovo je proba ovde
    </my-layout>
</template>
