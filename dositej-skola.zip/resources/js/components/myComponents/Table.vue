<template>
    <table class="w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400">
        <slot/>
    </table>
</template>
<script setup lang="ts">

</script>
